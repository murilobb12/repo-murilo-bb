package br.com.bb.t99.services;

public class UsuarioServiceTest {

}
